<?php

return [
'email' => 'Email',
'password' => 'Password',
'prefix' => 'Prefix Only letters and number are allowed',
'Email' => 'email',
'pre' => 'prefix_',
'select' => 'Select a plan to get started',
'basic' => 'Basic Plan',
'starter' => 'Starter Plan',
'advance' => 'Advance Plan',
'export' => 'Expert',
'demo' => 'demo', 
'next' => 'Next',
'' => '',




];