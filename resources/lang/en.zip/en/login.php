<?php

return [
    'password'  => 'Password',
    'email' => 'E-Mail Address',
    'login' => 'Login ',
    'remember' => 'Remember Me',
    'forgot' => 'Forgot Your Password?',
    'dont' => 'Dont have an Account ?    ',
    'signUp' => 'Sign Up',
    '' => '',
   
];